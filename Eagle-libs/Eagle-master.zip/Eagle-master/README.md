# Eagle Libraries

Although I have probably used these — please treat them as untested.

Teensy356.lbr — Teensy 3.5 and 3.6

eurohelper.lbr – 4, 6, 8 and 10hp PCB and panel templates for Eurorack. Delete your dims and drop one in.
